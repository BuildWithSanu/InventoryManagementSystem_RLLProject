export class Item {
    itemId!:number;
    itemName!:string;
    itemDescription!:string;
    itemCategory!:string;
    itemPrice!:number;
    itemQuantity!:number;
    vendorId!:number;
}
