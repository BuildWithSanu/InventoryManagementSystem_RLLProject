export class Dealer {
    vendorId!:number;
    vendorName!:string;
    vendorEmail!:string;
    vendorPhone!:number;
    vendorAddress!:string;
    vendorPassword!:string;
}
