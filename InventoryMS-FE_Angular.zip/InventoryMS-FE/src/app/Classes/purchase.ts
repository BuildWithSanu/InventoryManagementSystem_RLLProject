export class Purchase {
    purchaseId!:number;
    itemId!:number;
    itemName!:string;
    purchaseQuantity!:number;
    purchaseDate!:string;
    totalPrice!:number;
    pricePerItem!:number;
    customerId!:number;
    customerName!:string;
}
